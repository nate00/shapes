#Shapes

A simple game-making framework for Java, designed for the noob hackathon.

To get started, compile and run MyGame.java. You should see an empty window pop up with a blue background. Now open MyGame.java and MyCircle.java. This is where you'll be writing code.

To see some example code, open MazeGame.java and MazeHero.java. You can compile and run MazeGame.java to see how it works.

To see the (partially completed) documentation, open docs/index.html in a web browser.
