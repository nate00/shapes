import shapes.*;
import java.awt.Color;

public class MyCircle extends Circle {

  @Override
  public void setup() {
    // Put code here!

    // This code will be executed when your circle gets created.
  }

  @Override
  public void update() {
    // Put code here!

    // This code will be executed once per frame.
  }
}
